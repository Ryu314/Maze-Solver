from cisc106 import assertEqual


m1 = Maze(4, [[2, 2],[3, 4],[1, 4],[3, 2],[1, 3]], [1, 1], [3, 3])
m2 = Maze(3, [], [1,1], [3,3])
p1 = make_path(get_start_square(m1), ['UP', 'UP', 'UP'])
p2 = make_path(get_start_square(m1), ['UP', 'UP', 'DOWN'])
p3 = make_path(get_start_square(m1), ['UP', 'UP', 'UP', 'RIGHT', 'RIGHT', 'DOWN'])
p4 = make_path(get_start_square(m2), ['UP', 'UP', 'RIGHT', 'DOWN', 'DOWN', 'RIGHT', 'UP', 'LEFT'])

assertEqual(make_start_path(maze), make_path(maze, []))
assertEqual(list_of_moves(p1), ['UP', 'UP', 'UP'])
assertEqual(get_path_length(p1), 3)
assertEqual(get_end_position(p1, m1), make_square(4,1))
assertEqual(eval_path(m1, p1), 9)
assertEqual(move_right(p1, m1), make_path(make_square(1,1), ['UP', 'UP', 'UP', 'RIGHT']))
assertEqual(move_left(p1, m1), None)
assertEqual(is_not_retracing(p1, m1), True)
assertEqual(is_not_retracing(p2, m1), False)
assertEqual(is_not_retracing(p4, m2), False)
assertEqual(is_path_found(p3, m1), True)
assertEqual(is_path_found(p1, m1), False)