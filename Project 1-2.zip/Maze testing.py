from cisc106 import assertEqual

m1 = Maze(4, [[2, 2],[3, 4],[1, 4],[3, 2],[1, 3]], [1, 1], [3, 3])
assertEqual(m1.get_maze_size(), 4)
assertEqual(m1.get_color(2,2), 'B')
assertEqual(m1.get_start_square(), make_square(1,1))
assertEqual(m1.get_end_square(), make_square(3,3))
assertEqual(m1.get_eval_square(1,1), 6)
assertEqual(m1.square_up(make_square(4,4)), None)
assertEqual(m1.is_white_square(make_square(2,2), False)
assertEqual(m1.count_black_squares(make_square(1,4), make_square(1,4)), 1)
assertEqual(m1.square_right(4,3), make_square(4,4)