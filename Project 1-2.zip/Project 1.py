from cisc106 import assertEqual

def make_square(row, col):
    return {row: col}
def get_row(square):
    x = 0
    for i in square.keys():
        x = i
    return x
def get_col(square):
    return square[get_row(square)]
        
class Maze:
    def __init__(self, size, black_squares, start_pair, end_pair):
        self.size = size
        self.black_squares = black_squares
        self.start_pair = start_pair
        self.end_pair = end_pair
    def get_maze_size(self):
        return self.size
    def get_start_square(self):
        return make_square(self.start_pair[0], self.start_pair[1])
    def get_end_square(self):
        return make_square(self.end_pair[0], self.end_pair[1])
    def get_color(self, row, col):
        for i in self.get_black_squares():
            if [row, col] == i:
                return 'B'
        return 'W'
    def get_black_squares(self):
        return self.black_squares
    def distance(self, square1, square2):
        return abs(get_row(square1) - get_row(square2)) + abs(get_col(square1) - get_col(square2))
    def square_right(self, square):
        if get_col(square) < self.size and self.get_color(get_row(square), get_col(square)+1) == 'W':
            return make_square(get_row(square), get_col(square)+1)
        else:
            return None
    def square_up(self, square):
        if get_row(square) < self.size and self.get_color(get_row(square)+1, get_col(square)) == 'W':
            return make_square(get_row(square)+1, get_col(square))
        else:
            return None  
    def square_left(self, square):
        if get_col(square) > 1 and self.get_color(get_row(square), get_col(square)-1) == 'W':
            return make_square(get_row(square), get_col(square)-1)
        else:
            return None
    def square_down(self, square):
        if get_row(square) > 1 and self.get_color(get_row(square)-1, get_col(square)) == 'W':
            return make_square(get_row(square)-1, get_col(square))
        else:
            return None
    def eval_square(self, square):
        dist = self.distance(square, self.get_end_square())
    def is_white_square(self, square):
        if get_color(get_row(square), get_col(square)) == 'W':
            return True
        return False
    def is_black_square(self, square):
        if self.get_color(get_row(square), get_col(square)) == 'B':
            return True
        return False        
    def count_black_squares(self, square1, square2):
        num_black_squares = 0
        for rows in range(get_row(square1) + 1, get_row(square2) + 1):
            for cols in range(get_col(square1) + 1, get_col(square2) + 1):
                if is_black_square(make_square(rows, cols)):
                    num_black_squares += 1
        return num+black+squares
    def print_maze(self, path):
        for i in range(1, self.get_maze_size() + 1):
            print('\n')
            for j in range(1, self.get_maze_size() + 1):
                if make_square(self.get_maze_size() + 1 - i,j) == self.get_start_square():
                    print('S', end=' ')
                elif self.is_black_square(make_square(self.get_maze_size() + 1 - i,j)):
                    print('B', end=' ')
                elif square_list(path, self).count(make_square(self.get_maze_size() + 1 - i,j)) == 1:
                    print('x', end=' ')
                elif make_square(self.get_maze_size() + 1 - i,j) == self.get_end_square():
                    print('E', end=' ')
                else:
                    print('_', end=' ')
        
def make_path(start_square, moves):
    return (start_square, moves)
def start_square(path):
    return path[0]
def list_of_moves(path):
    return path[1]
def make_start_path(maze):
    return make_path(maze.get_start_square(), [])
def get_path_length(path):
    number_of_moves = 0
    for elt in list_of_moves(path):
        number_of_moves += 1
    return number_of_moves
def get_end_position(path, maze):
    end = start_square(path)
    for elt in list_of_moves(path):
        if elt == 'UP':
            end = maze.square_up(end)
        if elt == 'DOWN':
            end = maze.square_down(end)
        if elt == 'RIGHT':
            end = maze.square_right(end)
        if elt == 'LEFT':
            end = maze.square_left(end)
    return end
def eval_path(maze, path):
    return get_path_length(path) + 2 * maze.distance(get_end_position(path, maze), maze.get_end_square())
def square_list(path, maze):
    square = start_square(path)
    alist = [square]
    for elt in list_of_moves(path):
        if elt == 'UP':
            square = maze.square_up(square)
            alist += [square]
        elif elt == 'DOWN':
            square = maze.square_down(square)
            alist += [square]
        elif elt == 'RIGHT':
            square = maze.square_right(square)
            alist += [square]
        elif elt == 'LEFT':
            square = maze.square_left(square)
            alist += [square]   
    return alist
def is_not_retracing(path, maze):
    return not check_list(square_list(path, maze))
def check_list(alist):
    has_same_element = False
    for i in alist:
        if alist.count(i) >=2:
            has_same_element = True
    return has_same_element        
def is_path_found(path, maze):
    if get_end_position(path, maze) == maze.get_end_square():
        return True
    return False
def move_up(path, maze):
    if(not maze.square_up(get_end_position(path, maze))):
        return None
    x = make_path(start_square(path), list_of_moves(path) + ['UP'])
    if(is_not_retracing(x, maze)):
        return x
def move_down(path, maze):
    if(not maze.square_down(get_end_position(path, maze))):
        return None
    x = make_path(start_square(path), list_of_moves(path) + ['DOWN'])
    if(is_not_retracing(x, maze)):
        return x
def move_right(path, maze):
    if(not maze.square_right(get_end_position(path, maze))):
        return None
    x = make_path(start_square(path), list_of_moves(path) + ['RIGHT'])
    if(is_not_retracing(x, maze)):
        return x
def move_left(path, maze):
    if(not maze.square_left(get_end_position(path, maze))):
        return None
    x = make_path(start_square(path), list_of_moves(path) + ['LEFT'])
    if(is_not_retracing(x, maze)):
        return x

class PartialSolution:
    def __init__(self, path, rating):
        self.path = path
        self.rating = rating
    def get_path(self):    
        return self.path
    def get_eval(self, maze):
        dist = self.rating
        if not maze.square_up(get_end_position(self.path, maze)):
            dist += 4
        elif not maze.square_right(get_end_position(self.path, maze)):
            dist += 4
        elif not maze.square_left(get_end_position(self.path, maze)):
            dist += 4        
        elif not maze.square_down(get_end_position(self.path, maze)):
            dist += 4        
        return dist
    def is_solution_maze(self, maze):
        if is_path_found(self.get_path(), maze):
            return True
        else:
            return False
    def expand_partial_solution(self, maze):
        ps_set = [self]
        if move_up(self.path, maze):
            ps_set += [PartialSolution(move_up(self.path, maze), eval_path(maze, move_up(self.path, maze)))]
        if move_down(self.path, maze):
            ps_set += [PartialSolution(move_down(self.path, maze), eval_path(maze, move_down(self.path, maze)))]
        if move_right(self.path, maze):
            ps_set += [PartialSolution(move_right(self.path, maze), eval_path(maze, move_right(self.path, maze)))]
        if move_left(self.path, maze):
            ps_set += [PartialSolution(move_left(self.path, maze), eval_path(maze, move_left(self.path, maze)))]
        return ps_set
    def get_set_of_moves(self):
        return list_of_moves(self.path)

def combine_ps_sets(pss1, pss2):
    return pss1 + pss2
def make_ps_set(ps1):
    return [ps1]
def add_partial_solution(pss, ps):
    return pss + [ps]
def remove_partial_solution(pss, ps):
    pss.remove(ps)
    return pss
def make_empty_partial_solution(maze):
    i = PartialSolution(make_start_path(maze), eval_path(maze, make_start_path(maze)))
    return i
def get_best_partial_solution(pss, maze):
    ps = pss[0]
    for i in pss:
        if i.get_eval(maze) < ps.get_eval(maze):
            ps = i
    return ps
        


def find_path(maze):
    ps = make_empty_partial_solution(maze)
    ps_set = ps.expand_partial_solution(maze) 
    ps_set = remove_partial_solution(ps_set,ps)    
    while(not get_best_partial_solution(ps_set, maze).is_solution_maze(maze)):
        ps = get_best_partial_solution(ps_set, maze)
        ps_set = combine_ps_sets(ps_set, ps.expand_partial_solution(maze))
        ps_set = remove_partial_solution(ps_set,ps)
        ps_set = remove_partial_solution(ps_set,ps)
        maze.print_maze(ps.get_path())
    return get_best_partial_solution(ps_set, maze).get_set_of_moves()

m1 = Maze(4, [[3,2], [2,3]], [1, 1], [3, 3])
m2 = Maze(4, [[2, 2],[3, 4],[1, 4],[3, 2],[1, 3]], [1, 1], [3, 3])
p2 = make_path(make_square(1, 1), ['UP', 'UP', 'UP', 'RIGHT', 'RIGHT', 'DOWN'])
print(is_path_found(p2, m2))
m2.print_maze(p2)